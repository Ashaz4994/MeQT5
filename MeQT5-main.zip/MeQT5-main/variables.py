tavily_api = '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'
auth_token = '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'